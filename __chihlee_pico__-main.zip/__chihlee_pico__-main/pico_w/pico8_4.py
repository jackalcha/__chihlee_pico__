import time

print(time.gmtime())
print(time.localtime())