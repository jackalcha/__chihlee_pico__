# __chihlee_pico__
致理pico_w課程,第2節上課

# 上課網址
https://meet.google.com/rgg-rywi-hbw

# 上課錄影

## [2023_11_11_上午](https://youtube.com/live/d4kCf4p2T6E)

## [2023_11_11_下午](https://youtube.com/live/pVvPs_qJhNY)

## [2023_11_26_上午](https://youtube.com/live/xjF-LAo4vEY)

## [2023_11_26_下午](https://youtube.com/live/WtbsFRo0s5U)

## [2023_12_03_上午](https://youtube.com/live/0BnhcdTyDCU)

## [2023_12_03_下午](https://youtube.com/live/Ol4FaxD5gRA)

## [2023_12_10_上午](https://youtube.com/live/1SQZFUCGzak)

## [2023_12_10_下午](https://youtube.com/live/aEvrcbNypIc)

## [2023_12_16_上午](https://youtube.com/live/9fKW1rJMfFY)

## [2023_12_16_下午](https://youtube.com/live/r4Sy24Yi2Ho)

## [2024_01_06_早上](https://youtube.com/live/F8bdmPqvkn8)

## [2024_01_06_下午](https://youtube.com/live/iN4Tf5mYBSc)

## [2024_01_20_早上](https://youtube.com/live/w5-RQI6SJco)

## [2024_01_20_下午](https://youtube.com/live/cOKGWs5K_3o)

## [2024_01_26_早上](https://youtube.com/live/braPQyv3Wdo)

## [2024_01_26_下午](https://youtube.com/live/DyafTsMWiUs)

## [2024_02_03_早上](https://youtube.com/live/XygREGfiuxE)

## [2024_02_03_下午](https://youtube.com/live/ta2dgiVlLIo)
